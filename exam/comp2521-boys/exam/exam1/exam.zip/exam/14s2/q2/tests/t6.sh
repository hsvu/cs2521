./q2 < tests/t6.in | sort
