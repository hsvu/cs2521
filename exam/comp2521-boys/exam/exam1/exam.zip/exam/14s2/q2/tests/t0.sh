./q2 < tests/t0.in| sort
