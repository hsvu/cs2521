./q2 < tests/t3.in | sort
