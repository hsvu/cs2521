./q2 tests/graph2 6 2 | sort -n
