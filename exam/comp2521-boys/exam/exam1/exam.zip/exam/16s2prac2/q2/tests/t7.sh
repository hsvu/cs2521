./q2 tests/graph2 11 2 | sort -n
