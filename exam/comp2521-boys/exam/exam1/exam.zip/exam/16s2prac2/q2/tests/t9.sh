./q2 tests/graph2 3 99 | sort -n
