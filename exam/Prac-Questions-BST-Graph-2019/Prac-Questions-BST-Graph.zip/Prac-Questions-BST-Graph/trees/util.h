int fun_sort(const void* a, const void* b);
