void findValTests();
void isBSTTests();
void kthSmallestTests();
void lowestCommonAncTests();
void successorTests();
