# Practise Graph Questions for 2521
Questions found in Graph.c/BST.c respectively, solutions in Solutions.c

Graph questions and solutions written by Paul Wochnowski and Brittany Evat for COMP2521 in 17s2

Tree questions and solutions written by Steven Strijakov for COMP1927 in 16s2

Please let me know via email if you find any issues and I'll fix them. paul.wochnowski@unsw.edu.au
